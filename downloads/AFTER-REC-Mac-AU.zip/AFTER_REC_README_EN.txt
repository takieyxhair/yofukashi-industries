━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AFTER REC
Recording Assist Plugin
REC FIRST.
REGRET LESS.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AFTER REC is a recording-assist plugin
designed for home vocal recording.

Instead of heavy sound shaping,
AFTER REC focuses on naturally reducing:
- clipping
- harshness
- room reflections
- unstable vocal peaks
- cheap direct-interface feeling

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【MAIN CONTROLS】

■ CLEAN
Naturally reduces harshness,
room reflections,
and untreated home-recording artifacts.

Internal Processing:
- Dynamic DeEsser
- Room Cleanup
- 8kHz Dynamic Tamer
- Preamp Feel
- HPF (when CLEAN > 0)

--------------------------------------------------

■ SAFE
Protects recordings from clipping
and sudden vocal overload.

Internal Processing:
- Soft Limiter
- Peak Protection
- Soft Saturation

※ No makeup gain is applied.

--------------------------------------------------

■ AIR
Adds subtle openness,
breath, and natural vocal shine.

Internal Processing:
- High Shelf
- Odd Harmonics
- Even Harmonics

--------------------------------------------------

■ EXPORT SAFE
Protects exported audio
from clipping accidents.

Internal Processing:
- Soft Clip
- -3dBFS Ceiling Protection

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【RECOMMENDED RECORDING LEVEL】

GREEN
Recommended recording range

ORANGE
Caution

RED
Clipping risk

Recommended vocal peaks:
Around -18dBFS to -10dBFS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【IMPORTANT】

AFTER REC is not designed to magically fix
bad recording environments.

Microphone distance,
room acoustics,
recording level,
and pop-filter placement
still matter.

AFTER REC simply helps make
home vocal recordings
slightly safer and easier to mix.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thanks for recording tonight.
YOFUKASHI INDUSTRIES

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━