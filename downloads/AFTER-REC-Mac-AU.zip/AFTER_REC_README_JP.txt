━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AFTER REC
Recording Assist Plugin
REC FIRST.
REGRET LESS.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

宅録ボーカルを、
Mixしやすい録り音へ整えるための
録音補助プラグイン。

強い音作りではなく、
clip、harshness、部屋鳴りなど、
宅録特有の問題を自然に整理します。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【MAIN CONTROLS】

■ CLEAN
宅録特有の harshness、
部屋鳴り、IF直刺し感を
自然に整理します。

内部処理：
- Dynamic DeEsser
- Room Cleanup
- 8kHz Dynamic Tamer
- Preamp Feel
- HPF（CLEAN > 0時）

--------------------------------------------------

■ SAFE
録音時のclip事故や
急ピークを自然に保護します。

内部処理：
- Soft Limiter
- Peak Protection
- Soft Saturation

※ makeup gainは行いません。

--------------------------------------------------

■ AIR
自然な息感と艶を追加します。

内部処理：
- High Shelf
- Odd Harmonics
- Even Harmonics

--------------------------------------------------

■ EXPORT SAFE
書き出し時のclip事故を防止します。

内部処理：
- Soft Clip
- -3dBFS Ceiling Protection

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【推奨録音レベル】

GREEN
適正録音レベル

ORANGE
少し危険

RED
clip危険ゾーン

推奨ピーク：
-18dBFS〜-10dBFS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【重要】

AFTER RECは、
録音環境そのものを
魔法のように変えるプラグインではありません。

マイク距離、
部屋環境、
録音レベル、
ポップガード位置など、
基本的な録音環境は重要です。

AFTER RECは、
それらを"少し補助する"
ためのREC補助プラグインです。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thanks for recording tonight.
YOFUKASHI INDUSTRIES

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
